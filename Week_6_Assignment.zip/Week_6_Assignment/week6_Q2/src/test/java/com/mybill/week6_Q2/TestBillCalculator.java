package com.mybill.week6_Q2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.mybill.bean.BillCalculator;

class TestBillCalculator {

	BillCalculator bill=new BillCalculator(100,0.18,10.0);
	
	@Test
	void testCalculateBill() {
		assertEquals(1180.39,bill.calculateBill(),0.4);
	}

}
