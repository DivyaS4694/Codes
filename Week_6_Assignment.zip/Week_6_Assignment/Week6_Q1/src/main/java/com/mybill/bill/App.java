package com.mybill.bill;

import java.text.DecimalFormat;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
    public static void main( String[] args ){
     //Spring configuration class is invoked
      ApplicationContext context = new ClassPathXmlApplicationContext("Spring.xml");
        BillCalculator bill = (BillCalculator)context.getBean("bill");
        
        // decimal formate
        String pattern="##.0";
        DecimalFormat df=new DecimalFormat(pattern);
        
        System.out.println("Total bill to pay is $"+(df.format(bill.calculateBill())));
        }
}